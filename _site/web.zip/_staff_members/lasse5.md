---
name: Lasse
position: Ansat
image_path: https://source.unsplash.com/collection/139386/602x602?a=.png

---
