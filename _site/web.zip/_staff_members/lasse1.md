---
name: Lasse
position: Ansat
image_path: https://source.unsplash.com/collection/139386/601x601?a=.png

---
