---
name: Lasse
position: Ansat
image_path: https://source.unsplash.com/collection/139386/600x600?a=.png

---
