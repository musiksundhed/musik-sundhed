---
name: Lasse
position: ansat
image_path: https://source.unsplash.com/collection/139386/605x605?a=.png
---
