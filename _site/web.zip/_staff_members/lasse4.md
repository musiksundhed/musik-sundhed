---
name: Lasse 
position: ansat
image_path: https://source.unsplash.com/collection/139386/603x603?a=.png

---
